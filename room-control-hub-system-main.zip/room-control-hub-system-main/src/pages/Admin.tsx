
import React from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { RoomProvider } from "@/context/RoomContext";
import Navbar from "@/components/layout/Navbar";
import AdminDashboard from "@/components/admin/AdminDashboard";

export function Admin() {
  const { user, isAdmin } = useAuth();

  // If user is not logged in, redirect to login
  if (!user) {
    return <Navigate to="/login" />;
  }

  // If user is not an admin, redirect to user view
  if (!isAdmin) {
    return <Navigate to="/room" />;
  }

  return (
    <RoomProvider>
      <div className="min-h-screen flex flex-col bg-gray-50">
        <Navbar />
        <div className="flex-grow">
          <AdminDashboard />
        </div>
      </div>
    </RoomProvider>
  );
}

export default Admin;
